package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;

public class Password {

    private String pass = "abc123";

    @FXML
    private PasswordField passwordField;

    @FXML
    private DialogPane passDialog;

    @FXML
    private Label tryAgain;

    @FXML
    private Label correct;

    @FXML
    private Button verified;

    public DialogPane getPassDialog(){
        return passDialog;
    }

    @FXML
    public void verify(){
        isMatching();
    }

    @FXML
    public boolean isMatching(){
        System.out.println(passwordField.getText());
        if(passwordField.getText().equals(pass)){
            return true;
        }else {
            return false;
        }
    }
}
