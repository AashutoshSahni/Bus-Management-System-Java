package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TextField;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class BusDController {

//    DialogPane dialogPane = new DialogPane();
//    dialogPane. ;
//    FXMLLoader fxmlLoader = new FXMLLoader();
//
    @FXML
    private TextField regNum;

    @FXML
    private DatePicker doj;

    private final Locale myLocale = Locale.getDefault(Locale.Category.FORMAT);

    @FXML
    private TextField dName;

    @FXML
     public void processResult() {
    try {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String RNum = regNum.getText().trim();
        LocalDate date = doj.getValue();
        String DOJ = date.format(formatter);
        String driver = dName.getText().trim();

        Bus bus = new Bus(RNum, DOJ, driver);
        //DataSource.getInstance().addBus(bus);
        DataSource.getInstance().setAddDetails(RNum, DOJ, driver);
    }catch (NullPointerException e){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Oops");
        alert.setContentText("No bus added since all fields were not filled !");
        alert.show();
    }

    }

}
