package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DataSource {

    public static final String DB_NAME ="bus_details.db";
    public static final String CONNECTION_STRING = "jdbc:sqlite:E:\\ME\\JAVA\\JavaPrograms\\BusReservationSystem\\" +
                                                    DB_NAME;

    public static final String TABLE_BUS ="BUS";
    public static final String COLUMN_BUS_RG_NUM = "regNum";
    public static final String COLUMN_BUS_DOJ = "DOJ";
    public static final String COLUMN_BUS_DNAME = "driverName";


    public static final String INSERT_DETAILS = "INSERT INTO " + TABLE_BUS + '(' +
            COLUMN_BUS_RG_NUM + ", " + COLUMN_BUS_DOJ + ", " + COLUMN_BUS_DNAME +
            ") VALUES(?,?,?)";

    public static final String SORTED_BUS_LIST = "SELECT * FROM " + TABLE_BUS +
            " ORDER BY " + COLUMN_BUS_DNAME + " COLLATE NOCASE";

    public static final String DELETE_BUS = "DELETE FROM " + TABLE_BUS + " WHERE " +
            COLUMN_BUS_RG_NUM + " = ?";

    public static final String UPDATE_BUS = "UPDATE " + TABLE_BUS + " SET " + COLUMN_BUS_RG_NUM +
             " = ?, " + COLUMN_BUS_DOJ + " = ?, " + COLUMN_BUS_DNAME + " = ? WHERE " +
            COLUMN_BUS_RG_NUM + " = ?";


    private Connection conn;

    private PreparedStatement addDetails;
    private PreparedStatement deleteBus;
    private PreparedStatement updateBus;


    private static DataSource instance  = new DataSource();

    public static DataSource getInstance(){
        return instance;
    }

    private List<Bus> items = new ArrayList<>();

    public void addBus(Bus bus){
            items.add(bus);
            System.out.println("size " + items.size());

    }

    public List<Bus> getAllBus(){
        return items;
    }

    public boolean open(){
        try {
            conn = DriverManager.getConnection(CONNECTION_STRING);
            addDetails = conn.prepareStatement(INSERT_DETAILS);
            deleteBus = conn.prepareStatement(DELETE_BUS);
            updateBus = conn.prepareStatement(UPDATE_BUS);
            return true;
        }catch (SQLException e){
            System.out.println("Couldn't connect to database");
            e.printStackTrace();
            return false;
        }
    }

    public void setAddDetails(String RN,String doj,String dN){
        try{
            conn.setAutoCommit(false);

            addDetails.setString(1,RN);
            addDetails.setString(2,doj);
            addDetails.setString(3,dN);

            int affectedRows = addDetails.executeUpdate();
            if(affectedRows == 1){
                conn.commit();
            }else {
                throw new SQLException("The bus insert failed");
            }
        }catch (Exception e){
            System.out.println("Insert bus exception: " + e.getMessage());
            try {
                System.out.println("Performing rollback");
                conn.rollback();
            } catch (SQLException e2) {
                System.out.println("Oh boy! Things are really bad! " + e2.getMessage());
            }
        }finally {
            try {
               // System.out.println("Resetting auto commit");
                conn.setAutoCommit(true);
            }catch (SQLException e){
                System.out.println("Couldn't reset");
            }
        }
    }

    public List<Bus> queryBus(){

        try(Statement statement = conn.createStatement();
            ResultSet results = statement.executeQuery(SORTED_BUS_LIST)){

        List<Bus> buses = new ArrayList<>();
        while (results.next()){
            Bus bus = new Bus();
            bus.setRegNo(results.getString(1));
            bus.setDOJ(results.getString(2));
            bus.setDriverName(results.getString(3));

            buses.add(bus);
        }
        return buses;
        }catch (SQLException e){
            System.out.println("Ouery failed " +  e.getMessage());
            return null;
        }
    }

    public void editBus(String RN,String doj,String dN,String regNum){
        try{
            conn.setAutoCommit(false);

            updateBus.setString(1,RN);
            updateBus.setString(2,doj);
            updateBus.setString(3,dN);
            updateBus.setString(4,regNum);

            int affectedRows = updateBus.executeUpdate();
            if(affectedRows == 1){
                conn.commit();
            }else {
                throw new SQLException("The bus insert failed");
            }

        }catch (SQLException e){
            System.out.println("Update bus exception: " + e.getMessage());
            e.printStackTrace();
            try {
                System.out.println("Performing rollback");
                conn.rollback();
            } catch (SQLException e2) {
                System.out.println("Oh boy! Things are really bad! " + e2.getMessage());
            }
        }finally {
            try {
                // System.out.println("Resetting auto commit");
                conn.setAutoCommit(true);
            }catch (SQLException e){
                System.out.println("Couldn't reset");
            }
        }
    }

    public boolean deleteBus(String regNum){
        System.out.println("yo1");
        try {
            conn.setAutoCommit(false);
            deleteBus.setString(1,regNum);

            System.out.println("yo2");
            int affectedRows = deleteBus.executeUpdate();
            if(affectedRows == 1){
                conn.commit();
                return true;
            }else {
                throw new SQLException("Couldn't delete the bus");

            }
        }catch (SQLException e){
            System.out.println("Delete bus exception " + e.getMessage());
            e.printStackTrace();
            try {
                System.out.println("Performing rollback");
                conn.rollback();
            }catch (SQLException e1){
                System.out.println("Couldn't perform rollback");
            }
        }finally {
            try {
                // System.out.println("Resetting auto commit");
                conn.setAutoCommit(true);
            }catch (SQLException e){
                System.out.println("Couldn't reset");
            }
        }
    return false;
    }



    public void close(){
        try{
            if(addDetails != null){
                addDetails.close();
            }

            if(updateBus != null){
                updateBus.close();
            }

            if(deleteBus!= null){
                deleteBus.close();
            }

            if(conn != null){
                conn.close();
            }


        }catch (SQLException e){
            System.out.println("Couldn't close the database");
            e.printStackTrace();
        }
    }

}
