package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.DatePicker;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Bus {
    private SimpleStringProperty regNo = new SimpleStringProperty();
    private SimpleStringProperty DOJ = new SimpleStringProperty();
    private SimpleStringProperty driverName = new SimpleStringProperty();

    public Bus(){

    }

    public Bus(String regNo, String DOJ, String driverName) {

        this.regNo.set(regNo);
        this.DOJ.set(DOJ);
        this.driverName.set(driverName);
    }

    public String getRegNo() {
        return regNo.get();
    }

    public void setRegNo(String regNo) {
        this.regNo.set(regNo);
    }

    public String getDOJ() {
        return DOJ.get();
    }

    public void setDOJ(String DOJ) {
        this.DOJ.set(DOJ);
    }

    public String getDriverName() {
        return driverName.getValue();
    }

    public void setDriverName(String driverName) {
        this.driverName.set(driverName);
    }
}
