package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Label;


public class BookedController {

    @FXML
    private Label from;
    @FXML
    private Label to;
    @FXML
    private Label time;
    @FXML
    private Label M;
    @FXML
    private Label F;
    @FXML
    private Label cost;


    public void setLabels(String from,String to,String time,String M, String F,String cost){
        this.from.setText(from);
        this.to.setText(to);
        this.time.setText(time);
        this.M.setText(M);
        this.F.setText(F);
        this.cost.setText(cost);

    }

}
