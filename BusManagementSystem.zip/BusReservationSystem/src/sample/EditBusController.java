package sample;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EditBusController {

    @FXML
    private TextField regNum;

    @FXML
    private DatePicker doj;

    @FXML
    private TextField dName;

    private String RNum;

    @FXML
    public void showOnScene(String rNum, String DOJ, String driver) {

        regNum.setText(rNum);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = LocalDate.parse(DOJ, dateTimeFormatter);
        doj.setValue(date);
        dName.setText(driver);
    }

    public void getRNum(String RNum){
        this.RNum = RNum;

    }
        @FXML
        public void processResult() {

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            String RNum = regNum.getText().trim();
            LocalDate localDate = doj.getValue();
            String doj= localDate.format(formatter);
            String driverName = dName.getText().trim();

            DataSource.getInstance().editBus(RNum,doj,driverName,this.RNum);

        }

}
