package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;

import java.io.IOException;
import java.util.Optional;

public class ManageController {

    @FXML
    private DialogPane manage;

    @FXML
    private TableView tableView;

    @FXML
    public void listDetails(){
        Task<ObservableList<Bus>>task = new
                Task<ObservableList<Bus>>() {
                    @Override
                    public ObservableList<Bus> call()  {
                        return FXCollections.observableArrayList(DataSource.getInstance().queryBus());
                    }
                };
         tableView.itemsProperty().bind(task.valueProperty());
         tableView.refresh();
        new Thread(task).start();
    }

    @FXML
    public void addBus(){

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(manage.getScene().getWindow());
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("AddBus.fxml"));
        dialog.setTitle("Add a Bus!");
        //ialog.setHeaderText("Use this dialog to manage bus");
        try{
            dialog.getDialogPane().setContent(fxmlLoader.load());

        }catch (IOException e){
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional result = dialog.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK){
        BusDController controller = fxmlLoader.getController();
        controller.processResult();
        listDetails();
    }

}

    @FXML
    public void deleteBus(){
        Bus bus = (Bus)tableView.getSelectionModel().getSelectedItem();
        if(bus != null) {
            Task<Boolean> task = new Task<Boolean>() {
                @Override
                protected Boolean call() throws Exception {
                    return DataSource.getInstance().deleteBus(bus.getRegNo());
                }
            };

            task.setOnSucceeded(e ->
                    listDetails());

            new Thread(task).start();
        } else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Oops");
                alert.setContentText("Please select one!!");
                alert.showAndWait();
            }
        }



    public void editBus(){
        final Bus bus = (Bus)tableView.getSelectionModel().getSelectedItem();
        if(bus != null) {
            String regNum = bus.getRegNo();
            String doj = bus.getDOJ();
            String driver = bus.getDriverName();
            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.initOwner(manage.getScene().getWindow());
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("editBus.fxml"));
            dialog.setTitle("Edit a Bus!");

            //ialog.setHeaderText("Use this dialog to manage bus");
            try {
                dialog.getDialogPane().setContent(fxmlLoader.load());

            } catch (IOException e) {
                System.out.println("Couldn't load the dialog");
                e.printStackTrace();
                return;
            }

            dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
            dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
            EditBusController controller = fxmlLoader.getController();
            controller.showOnScene(regNum, doj, driver);
            controller.getRNum(regNum);
            Optional result = dialog.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                controller.processResult();
                listDetails();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Oops");
            alert.setContentText("Please select one!!");
            alert.showAndWait();
        }

    }

}


