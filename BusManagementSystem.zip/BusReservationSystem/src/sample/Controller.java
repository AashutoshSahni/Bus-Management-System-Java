package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;


public class Controller {

    @FXML
    private ComboBox source;

    @FXML
    private ComboBox destination;

    @FXML
    private ComboBox timings;

    @FXML
    private TextField male;

    @FXML
    private TextField female;

    @FXML
    private BorderPane mainBorderPane;

    @FXML
     public void manageBus(){


        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(mainBorderPane.getScene().getWindow());
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("PassCode.fxml"));
        dialog.setTitle("Password Please!");
        //ialog.setHeaderText("Use this dialog to manage bus");
        try{
            dialog.getDialogPane().setContent(fxmlLoader.load());

        }catch (IOException e){
            System.out.println("Couldn't load the dialog");
            e.printStackTrace();
            return;
        }

        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        dialog.setResizable(true);
        dialog.setHeight(10);
        dialog.setWidth(20);

        Optional<ButtonType> result = dialog.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK ) {

            Password controller = fxmlLoader.getController();

            if(controller.isMatching()) {

                FXMLLoader fxmlLoader1 = new FXMLLoader();
                fxmlLoader1.setLocation(getClass().getResource("manageBus.fxml"));

                dialog.setTitle("Manage Bus");
                dialog.setHeaderText("Use this dialog to manage bus");

                try {
                    dialog.getDialogPane().setContent(fxmlLoader1.load());

                } catch (IOException e) {
                    System.out.println("Couldn't load the dialog");
                    e.printStackTrace();
                    return;
                }
                ManageController controller1 = fxmlLoader1.getController();
                controller1.listDetails();

                Optional<ButtonType> newResult = dialog.showAndWait();

            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Oops");
                alert.setContentText("Wrong Password!");
                alert.show();

            }

        }
     }

     @FXML
     public void bookTicket() {
        try {
            String from = source.getSelectionModel().getSelectedItem().toString();
            String to = destination.getSelectionModel().getSelectedItem().toString();
            String time = timings.getSelectionModel().getSelectedItem().toString();
            String M = male.getText();
            String F = female.getText();
            int cost = getCost(from,to);
            int m = Integer.parseInt(M);
            int f = Integer.parseInt(F);
            System.out.println(m + f);
            System.out.println((m+f)*cost);
            String totalCost = Integer.toString((m+f)*cost);
            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.initOwner(mainBorderPane.getScene().getWindow());
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("TicketBooked.fxml"));
            dialog.setTitle("Tickets booked!");
            //ialog.setHeaderText("Use this dialog to manage bus");
            try {
                dialog.getDialogPane().setContent(fxmlLoader.load());

            } catch (IOException e) {
                System.out.println("Couldn't load the dialog");
                e.printStackTrace();
                return;
            }

            dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
            dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

            BookedController controller = fxmlLoader.getController();
            controller.setLabels(from, to, time, M, F,totalCost);
            Optional<ButtonType> result = dialog.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {

            }


     }catch (NullPointerException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Oops");
            alert.setContentText("Cannot leave empty");
            alert.show();
        }catch (NumberFormatException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Oops");
            alert.setContentText("Cannot leave empty");
            alert.show();
        }

    }

    @FXML
    public void reset(){
        source.getSelectionModel().clearSelection();
        destination.getSelectionModel().clearSelection();
        timings.getSelectionModel().clearSelection();
        male.clear();
        female.clear();
    }

    public int getCost(String from,String to){
        
        if(from.equals("Bhopal")&& to.equals("Indore") || from.equals("Indore") && to.equals("Bhopal")){
         return 70;
        }else if(from.equals("Bhopal") && to.equals("Gwalior") || from.equals("Gwalior")&& to.equals("Bhopal")){
            return 165;
        }else if(from.equals("Bhopal") && to.equals( "Jabalpur") || from.equals("Jabalpur")&& to.equals("Bhopal")){
            return 130;
        }else if(from.equals("Gwalior") && to.equals("Indore") || from.equals("Indore")&& to.equals("Gwalior")){
            return 235;
        }else if(from.equals("Gwalior") && to.equals("Jabalpur") || from.equals( "Jabalpur")&& to.equals("Gwalior")){
            return 200;
        }else if(from.equals("Indore") && to.equals("Jabalpur") || from.equals( "Jabalpur")&& to.equals("Indore")){
            return 270;
        }else {
            return 0;
        }

    }

}
